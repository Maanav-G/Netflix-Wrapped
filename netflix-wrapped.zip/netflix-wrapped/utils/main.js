function getTest() {
    return "getTest() works"
}